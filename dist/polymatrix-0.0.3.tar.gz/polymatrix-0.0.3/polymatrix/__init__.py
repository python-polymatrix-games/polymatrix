name = "polymatrix"

from .main import PolymatrixGame, GameManager, QuickPolymatrixGame, QuickGame
from .test import TestGame