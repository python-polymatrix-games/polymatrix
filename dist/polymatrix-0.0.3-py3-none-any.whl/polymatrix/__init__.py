name = "polymatrix"

from .main import PolymatrixGame, GameManager, QuickPolymatrixGame, QuickGame